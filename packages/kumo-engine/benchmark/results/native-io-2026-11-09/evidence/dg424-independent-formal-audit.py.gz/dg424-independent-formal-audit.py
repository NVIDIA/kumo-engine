"""Independent saved-data audit; imports no benchmark validators or models."""
import hashlib
import json
import math
import statistics
from collections import defaultdict

from io_utils import fsutil

SOURCE = '75ca0e2fd6797827feda61d637b59b75e2d6f678'
NATIVE = 'a5949f96723df2684c6cdbd5884bcc25c72129c8a629bfffa49bc36f9552140f'
WHEEL = 'b85a88f9bf09ce88f166c882ea0e1c64e97b743e071e1d924e0552c709e8be0c'
PROVENANCE = 'c17db9f37c6a2ffd4d955d2bc57d898da63c7586856eae9ae0299391c2cd68cf'
EMPTY = hashlib.sha256(b'').hexdigest()


def digest(text):
    return hashlib.sha256(text.encode()).hexdigest()


def close(a, b):
    assert math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-12), (a, b)


proof_path = '/tmp/dg424-phase7-formal-completion-proof.json'
proof_text = fsutil.read_text(proof_path)
proof = json.loads(proof_text)
paths = proof['raw_paths']
assert len(paths) == len(set(paths)) == 90
groups, tasks, raw_hashes = defaultdict(dict), defaultdict(list), {}
pids, scopes, durations, pressure = set(), set(), [], []
for path in paths:
    text = fsutil.read_text(path)
    row = json.loads(text)
    raw_hashes[path] = digest(text)
    spec, work = row['matrix_spec'], row['work']
    task, regime, repeat, backend = (row[k] for k in ('task', 'regime', 'repeat', 'backend'))
    assert row['status'] == 'PASS' and repeat == spec['repeat']
    assert spec['source_provenance']['git_sha'] == SOURCE
    assert spec['source_provenance']['tracked_diff_sha256'] == EMPTY
    assert spec['build_provenance_sha256'] == PROVENANCE
    build = row['provenance']['build']
    assert build['source_git_head'] == build['build_commit_override'] == SOURCE
    assert build['profile'] == 'release' and build['wheel']['sha256'] == WHEEL
    assert row['provenance']['native_sha256'] == NATIVE
    assert (spec['io_rings'], spec['io_qd'], spec['io_batch_mult']) == (8, 256, 1)
    assert (spec['workers'], spec['torch_threads'], spec['threads']) == (0, 1, 4)
    expected_cache = 16 if regime == 'resident' else (1 if task == 'temporal_link' else 2)
    assert spec['direct_cache_gib'] == expected_cache
    for phase in ('fit', 'predict', 'repeat', 'reload'):
        snapshot = row['native_io'][phase]['after']
        assert snapshot['configured_backend'] == backend
        assert snapshot['cache_capacity_pages'] == (expected_cache * 262144 if backend == 'direct' else 0)
        assert snapshot['runtime_rings'] == (0 if backend == 'mmap' else 8)
    batches = 256 if task == 'temporal_link' else 1280
    updates = 512 if task == 'temporal_link' else 1280
    assert spec['steps'] == work['train_batches'] == batches
    assert work['optimizer_steps'] == work['selected_checkpoint_steps'] == updates
    assert work['optimizer_count'] == (2 if task == 'temporal_link' else 1)
    assert all(x['effective'] == dict(mode='standalone', num_workers=0, rayon_threads=4) for x in work['loaders'])
    assert len(work['tt_ingest_layouts']) == len(work['tt_ingest_calls']) == 4
    assert {x['phase'] for x in work['tt_ingest_layouts']} == {'fit', 'predict', 'repeat', 'reload'}
    expected_shards = 3 if task == 'temporal_link' else 1
    for layout in work['tt_ingest_layouts']:
        assert layout['actual_num_shards'] == expected_shards
        assert set(layout['stage_shards'].values()) == {expected_shards}
    for call in work['tt_ingest_calls']:
        assert call['context_threads'] == call['encode_threads'] == 1
        assert call['num_shards'] == (3 if task == 'temporal_link' else None)
    interval = work['training_interval']
    duration = row['phase_seconds']['training']
    assert duration >= 30
    close(duration, interval['seconds'])
    durations.append(duration)
    before, after = interval['resources_before'], interval['resources_after']
    pid = interval['native_after']['pid']
    assert pid == before['observer_process']['pid'] == after['observer_process']['pid']
    assert all(row['native_io'][p]['after']['pid'] == pid for p in ('fit', 'predict', 'repeat', 'reload'))
    assert pid not in pids
    pids.add(pid)
    scope = row['resources']['cgroup']
    assert scope not in scopes
    scopes.add(scope)
    memory = 64 * 1024**3 if regime == 'resident' else 4 * 1024**3
    assert spec['memory_bytes'] == memory == int(after['memory_max'])
    assert after['swap_max'] == '0'
    snapshots = [row['resources']['after']] + [p['after'] for p in row['resources_per_phase'].values()]
    assert all(s['memory_events'][k] == 0 for s in snapshots for k in ('oom', 'oom_kill', 'oom_group_kill'))
    reads = after['observer_process']['io']['read_bytes'] - before['observer_process']['io']['read_bytes']
    scans = after['memory_stat']['pgscan'] - before['memory_stat']['pgscan']
    evictions = interval['native_after']['evictions'] - interval['native_before']['evictions']
    assert reads == row['training_evidence']['pid_physical_read_bytes']
    assert scans == row['training_evidence']['cgroup_pgscan']
    assert evictions == row['training_evidence']['native_cache_evictions']
    if regime == 'constrained':
        assert reads > 0 and (scans > 0 or (backend == 'direct' and evictions > 0))
        pressure.append(dict(task=task, backend=backend, repeat=repeat, reads=reads, scans=scans, native_evictions=evictions))
    identity = (repeat, backend)
    assert identity not in groups[task + '/' + regime]
    groups[task + '/' + regime][identity] = row
    tasks[task].append(row)

assert len(groups) == 6 and len(tasks) == 3 and len(pids) == len(scopes) == 90
task_checks = {}
for task, rows in tasks.items():
    assert len(rows) == 30
    first = rows[0]
    for row in rows:
        for key in ('config', 'config_sha256', 'requested_model_plan', 'predictions'):
            assert row[key] == first[key], (task, key)
        for key in ('logical_seed_sha256', 'tt_ingest_layouts', 'train_batches', 'predict_rows', 'predict_batches'):
            assert row['work'][key] == first['work'][key], (task, key)
    task_checks[task] = dict(rows=30, exact_predictions=True, exact_config=True, exact_logical_stream=True, exact_layouts=True)

stats = {}
for name, rows in groups.items():
    assert set(rows) == {(r, b) for r in range(5) for b in ('mmap', 'buffered', 'direct')}
    group = proof['groups'][name]
    summary_text = fsutil.read_text(group['summary_path'])
    assert digest(summary_text) == group['summary_sha256']
    summary = json.loads(summary_text)
    assert summary['status'] == 'PASS' and summary['repetitions'] == 5 and not summary['pilot']
    stats[name] = {}
    for backend in ('mmap', 'buffered', 'direct'):
        values = [rows[r, backend]['phase_seconds'] for r in range(5)]
        medians = {phase: statistics.median(v[phase] for v in values) for phase in ('fit', 'predict', 'e2e', 'training')}
        ratios = [rows[r, 'mmap']['phase_seconds']['e2e'] / rows[r, backend]['phase_seconds']['e2e'] for r in range(5)]
        recorded = summary['groups'][name][backend]
        for phase, median in medians.items():
            close(median, recorded[phase]['median_seconds'])
        for actual, saved in zip(ratios, recorded['e2e']['paired_speedups'], strict=True):
            close(actual, saved)
        close(statistics.median(ratios), recorded['e2e']['median_speedup'])
        stats[name][backend] = dict(median_seconds=medians, paired_e2e_ratios=ratios, median_paired_e2e_ratio=statistics.median(ratios))
result = dict(status='PASS', method='Independent Python assertions; no canonical validator imported; bootstrap not recomputed', source=SOURCE, native=NATIVE, proof_path=proof_path, proof_sha256=digest(proof_text), trials=90, groups=6, unique_pids=len(pids), unique_scopes=len(scopes), min_training_seconds=min(durations), constrained_pressure_trials=len(pressure), oom_events=0, task_checks=task_checks, stats=stats, constrained_pressure=pressure, raw_sha256=raw_hashes, scope_limits='64GiB resident/4GiB constrained, swap0; physical I/O is training PID, OS scan and native evictions reported separately')
out = '/tmp/dg424-independent-formal-audit.json'
fsutil.write_text(out, json.dumps(result, indent=2) + '\n')
print(out)
for name, backends in stats.items():
    print(name, {b: (round(x['median_seconds']['training'], 3), round(x['median_seconds']['e2e'], 3), round(x['median_paired_e2e_ratio'], 4)) for b, x in backends.items()})
