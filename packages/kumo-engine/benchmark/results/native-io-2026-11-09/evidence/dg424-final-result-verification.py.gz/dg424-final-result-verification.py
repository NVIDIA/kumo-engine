# SPDX-FileCopyrightText: Copyright (c) 2026, NVIDIA CORPORATION & AFFILIATES.
# All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Verify rejection boundaries against a real archived benchmark package."""

import argparse
import copy
import json
import sys
from pathlib import Path

from io_utils import fsutil


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo-root', default=str(Path.cwd()))
    parser.add_argument('--package', required=True)
    parser.add_argument('--scratch', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    sys.path.insert(0, args.repo_root + '/packages/kumo-engine/benchmark')
    import native_io_results as package
    module = package.driver(args.repo_root)
    if fsutil.exists(args.scratch):
        raise FileExistsError(args.scratch)
    fsutil.makedirs(args.scratch)
    checks = []

    def rejects(name, operation):
        try:
            operation()
        except ValueError as error:
            checks.append(dict(name=name, status='PASS', reason=str(error)))
            return
        raise AssertionError(name)

    def fixture(name):
        target = args.scratch + '/' + name
        fsutil.makedirs(target)
        for filename in ('manifest.json', 'controls.json', 'raw-trials.jsonl.gz'):
            fsutil.copy(args.package + '/' + filename, target + '/' + filename)
        return target

    manifest = package.load(args.package + '/manifest.json')
    positive = package.replay(argparse.Namespace(
        repo_root=args.repo_root, replay=args.package), module)
    target = fixture('archive')
    archive = fsutil.read_binary(target + '/raw-trials.jsonl.gz')
    fsutil.write_binary(target + '/raw-trials.jsonl.gz', archive + b'corrupt')
    rejects('archive_corruption', lambda: package.replay(argparse.Namespace(
        repo_root=args.repo_root, replay=target), module))
    target = fixture('controls')
    controls = package.load(target + '/controls.json')
    controls[next(iter(controls))]['controls']['memory_bytes'] += 1
    package.dump(target + '/controls.json', controls)
    changed = package.load(target + '/manifest.json')
    changed['controls_sha256'] = package.sha(fsutil.read_binary(target + '/controls.json'))
    package.dump(target + '/manifest.json', changed)
    rejects('controls_tamper_with_updated_hash', lambda: package.replay(
        argparse.Namespace(repo_root=args.repo_root, replay=target), module))
    target = fixture('argv')
    changed = package.load(target + '/manifest.json')
    first = next(iter(changed['variants']))
    changed['variants'][first]['trials'][0]['command'].append('--wrong')
    package.dump(target + '/manifest.json', changed)
    rejects('executed_argv_tamper', lambda: package.replay(argparse.Namespace(
        repo_root=args.repo_root, replay=target), module))
    with fsutil.get_binary_handle(args.package + '/raw-trials.jsonl.gz', 'rb') as stream:
        original = json.loads(json.loads(stream.readline())['source_text'])
    short = copy.deepcopy(original)
    short['matrix_spec']['pilot'] = False
    short['work']['training_interval']['seconds'] = 1
    short['training_evidence'] = module.training_evidence(short, short['matrix_spec'])
    rejects('formal_short_training', lambda: package.report(module, [short], 1,
        manifest['order_seed'], manifest['prediction_atol']))
    pressure = copy.deepcopy(short)
    pressure['regime'] = pressure['matrix_spec']['regime'] = 'constrained'
    pressure['matrix_spec']['memory_bytes'] = 4 * 1024**3
    interval = pressure['work']['training_interval']
    interval['seconds'] = 31
    interval['resources_after']['observer_process']['io']['read_bytes'] = (
        interval['resources_before']['observer_process']['io']['read_bytes'])
    pressure['training_evidence'] = module.training_evidence(
        pressure, pressure['matrix_spec'])
    rejects('formal_missing_pressure', lambda: package.report(module, [pressure], 1,
        manifest['order_seed'], manifest['prediction_atol']))
    result = dict(status='PASS', positive_replay=positive, rejection_checks=checks,
                  order_seed=manifest['order_seed'],
                  helper_sha256=package.sha(fsutil.read_binary(package.__file__)))
    package.dump(args.output, result)
    print(json.dumps(result))


if __name__ == '__main__':
    main()
