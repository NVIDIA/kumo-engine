import gzip
import hashlib
import json
import sys

from io_utils import fsutil


def sha(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


results = []
all_paths = set()
for directory in sys.argv[1:]:
    manifest = json.loads(fsutil.read_text(directory + "/manifest.json"))
    archive = fsutil.read_binary(directory + "/raw-trials.jsonl.gz")
    assert sha(archive) == manifest["archive_sha256"]
    assert sha(fsutil.read_binary(directory + "/controls.json")) == (
        manifest["controls_sha256"]
    )
    rows = [json.loads(line) for line in gzip.decompress(archive).splitlines()]
    assert len(rows) == manifest["archive_records"]
    paths = set()
    for row in rows:
        source = row["source_file"]
        original = fsutil.read_text(source)
        assert row["source_text"] == original, source
        assert sha(original.encode()) == row["source_sha256"], source
        assert source not in paths and source not in all_paths, source
        paths.add(source)
        json.loads(original)
    all_paths.update(paths)
    expected = "DIAGNOSTIC" if manifest["diagnostic"] else "VALIDATED"
    assert all(v["status"] == expected for v in manifest["variants"].values())
    results.append({"directory": directory, "records": len(rows),
                    "archive_sha256": sha(archive), "status": "PASS"})

output = json.dumps({"status": "PASS", "records": len(all_paths),
                     "archives": results}, indent=2)
fsutil.write_text("/tmp/dg424-root-archive-audit.json", output + "\n")
print(output)
