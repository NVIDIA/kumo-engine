#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <linux/io_uring.h>
#include <errno.h>
#include <string.h>
int main(void) {
 struct io_uring_params p = {0};
 int ring = syscall(__NR_io_uring_setup, 2, &p);
 printf("io_uring_setup=%d errno=%d %s\n",ring,ring<0?errno:0,ring<0?strerror(errno):"OK");
 if(ring>=0) close(ring);
 const char *path="/tmp/dg424-benchmark-capabilities.bin";
 int fd=open(path,O_CREAT|O_TRUNC|O_RDWR,0600);
 void *buf=NULL; int rc=posix_memalign(&buf,4096,65536);
 if(fd<0||rc) return 1;
 memset(buf,0x42,65536); if(write(fd,buf,65536)!=65536||fsync(fd)) return 2;
 unsigned char *map=mmap(NULL,65536,PROT_READ,MAP_SHARED,fd,0); unsigned char vec[16]={0};
 volatile unsigned char warm=map[0]; (void)warm;
 mincore(map,65536,vec); int before=0; for(int i=0;i<16;i++) before+=vec[i]&1;
 munmap(map,65536); rc=posix_fadvise(fd,0,0,POSIX_FADV_DONTNEED);
 map=mmap(NULL,65536,PROT_READ,MAP_SHARED,fd,0); mincore(map,65536,vec); int after=0;for(int i=0;i<16;i++) after+=vec[i]&1;
 printf("fadvise_dontneed=%d residency_pages=%d->%d\n",rc,before,after); munmap(map,65536);close(fd);
 fd=open(path,O_RDONLY|O_DIRECT); errno=0; ssize_t n=fd<0?-1:pread(fd,buf,4096,0);
 printf("O_DIRECT fd=%d read=%zd errno=%d %s first=%02x\n",fd,n,errno,strerror(errno),*(unsigned char*)buf);
 if(fd>=0) close(fd); free(buf);unlink(path);return 0;
}
