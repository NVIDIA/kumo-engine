"""Read saved diagnostic records only; never execute or import a model."""
import argparse
import json

from io_utils import fsutil


def lines(path):
    return [json.loads(line) for line in fsutil.read_text(path).splitlines() if line]


def compare_files(left, right):
    a = {item['path']: item for item in left}
    b = {item['path']: item for item in right}
    common = a.keys() & b.keys()
    changed = [path for path in sorted(common)
               if (a[path]['size'], a[path]['sha256']) !=
               (b[path]['size'], b[path]['sha256'])]
    return dict(left_files=len(a), right_files=len(b),
                left_only=sorted(a.keys() - b.keys()),
                right_only=sorted(b.keys() - a.keys()),
                byte_differences=changed,
                normalized_json_differences=[path for path in changed
                    if a[path].get('normalized_content') !=
                    b[path].get('normalized_content')])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('left')
    parser.add_argument('right')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    a = lines(args.left + '-batches.jsonl')
    b = lines(args.right + '-batches.jsonl')
    batches = []
    for left, right in zip(a, b, strict=True):
        field_names = sorted(left['fields'].keys() | right['fields'].keys())
        fields = {name: dict(left=left['fields'].get(name),
                            right=right['fields'].get(name))
                  for name in field_names
                  if left['fields'].get(name) != right['fields'].get(name)}
        positive_keys = ('ordered_sha256', 'multiset_sha256', 'set_sha256')
        batches.append(dict(batch=left['batch'],
            logical_equal=left['logical_sha256'] == right['logical_sha256'],
            field_differences=fields,
            positive_equal={key: left['positives'][key] == right['positives'][key]
                            for key in positive_keys},
            left_first_anchors=left['positives']['first_anchors'],
            right_first_anchors=right['positives']['first_anchors']))
    a = lines(args.left + '-ingests.jsonl')
    b = lines(args.right + '-ingests.jsonl')
    ingests = []
    for left, right in zip(a, b, strict=True):
        if left['namespace'] != right['namespace']:
            raise ValueError('Mismatched phase namespaces')
        ingests.append(dict(namespace=left['namespace'],
            source=compare_files(left['source_files'], right['source_files']),
            extension=compare_files(left['files'], right['files'])))
    result = dict(left=args.left, right=args.right,
                  batches=batches, ingests=ingests)
    fsutil.write_text(args.output, json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(output=args.output,
        traced_batches=len(batches), ingests=len(ingests),
        first_differing_batch=next((r['batch'] for r in batches
            if not r['logical_equal'] or r['field_differences']), None),
        phase_differences=ingests)))


if __name__ == '__main__':
    main()
