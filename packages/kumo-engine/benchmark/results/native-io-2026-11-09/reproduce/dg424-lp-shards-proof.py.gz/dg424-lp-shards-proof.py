"""Explicitly gated paired-regime LP diagnostics; retained files, no timing claims."""

import argparse
import json
import os
import subprocess
import sys
import uuid

from io_utils import fsutil

REPO = '/home/dmawhirter/work/subtrees/kumo-engine-native-io-benchmarks'
sys.path.insert(0, REPO + '/packages/kumo-engine/benchmark')
from native_io_isolation import (  # noqa: E402
    clone_prepared,
    file_hash,
    verify_baseline,
)
from native_io_matrix import source_provenance, stop_scope  # noqa: E402
from native_io_resources import evict_files, owned_files  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--regime', required=True, choices=('resident', 'constrained'))
    parser.add_argument('--prefix', required=True)
    parser.add_argument('--steps', type=int, default=8)
    parser.add_argument('--trace-batches', type=int, default=8)
    parser.add_argument('--expected-source', required=True)
    parser.add_argument('--build-provenance', required=True)
    parser.add_argument('--go-confirmed', action='store_true')
    args = parser.parse_args()
    if not args.go_confirmed:
        parser.error('Root GO after the current model jobs terminate is required')
    if not 1 <= args.trace_batches <= args.steps:
        parser.error('Require1 <= trace-batches <= steps')
    baseline = '/tmp/dg424-benchmark-large/temporal_link'
    probe = '/tmp/dg424-lp-shards-probe.py'
    proof = args.build_provenance
    build = json.loads(fsutil.read_text(proof))
    if build['profile'] != 'release' or build['source_git_head'] != args.expected_source:
        raise ValueError('Optimized build proof must match the requested committed source')
    source = source_provenance(probe)
    if (source['git_sha'] != args.expected_source or
            source['tracked_diff_sha256'] !=
            'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'):
        raise ValueError('Diagnostic requires the requested clean committed source')
    for suffix in ('.json', '-spec.json', '-prepared', '-work'):
        if fsutil.exists(args.prefix + suffix):
            raise FileExistsError(args.prefix + suffix)
    original = json.loads(fsutil.read_text(baseline + '/manifest.json'))
    expected = {item['path']: item['sha256'] for item in original['pristine_owned_files']}
    manifest = clone_prepared(baseline, args.prefix + '-prepared',
                              expected_sha256=expected)
    eviction = evict_files(owned_files(manifest, args.prefix + '-prepared'))
    memory_gib = 64 if args.regime == 'resident' else 4
    spec = dict(
        task='temporal_link', regime=args.regime, repeat=0, backend='mmap',
        prepared_dir=baseline, runtime_prepared_dir=args.prefix + '-prepared',
        memory_bytes=memory_gib * 1024**3, steps=args.steps, batch_size=256,
        workers=0, threads=4, torch_threads=1, loader_mode='standalone', model_seed=0,
        python='/tmp/dg424-benchmark-run-python', runner=probe,
        result=args.prefix + '.json', log=args.prefix + '.log',
        resources=args.prefix + '-resources.json', eviction=eviction,
        timeout=3600, direct_cache_gib=1, io_rings=2, io_qd=32, io_batch_mult=1,
        cpus='5-9,15-19', source_provenance=source, pilot=True,
        min_training_seconds=30, cleanup_work=False, build_provenance=proof,
        build_provenance_sha256=file_hash(proof),
        prepared_manifest_sha256=file_hash(baseline + '/manifest.json'),
        runtime_manifest_sha256=file_hash(args.prefix + '-prepared/manifest.json'),
        diagnostic_purpose='LP per-field and fresh TT row-layout traces; no performance use',
        diagnostic_native_sha256=build['native']['sha256'],
        diagnostic_num_shards=3,
        diagnostic_probe_sha256=file_hash(probe))
    fsutil.write_text(args.prefix + '-spec.json', json.dumps(spec, indent=2) + '\n')
    environment = {
        **os.environ, 'DG_LP_TRACE_GO': '1', 'DG_LP_TRACE_PREFIX': args.prefix,
        'DG_LP_TRACE_EXPECTED_SOURCE': args.expected_source,
        'DG_LP_TRACE_BATCHES': str(args.trace_batches), 'DG_EDGE_BACKEND': 'mmap',
        'DG_DIRECT_CACHE_GB': '1', 'DG_IO_RINGS': '2', 'DG_IO_QD': '32',
        'DG_IO_BATCH_MULT': '1', 'RAYON_NUM_THREADS': '4', 'OMP_NUM_THREADS': '1',
        'OPENBLAS_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1', 'PYTHONHASHSEED': '0',
    }
    unit = 'dg-lp-regime-proof-' + uuid.uuid4().hex
    command = [
        'systemd-run', '--user', '--scope', '--quiet', f'--unit={unit}',
        '-p', f'MemoryMax={memory_gib * 1024**3}', '-p', 'MemorySwapMax=0',
        '-p', 'IOAccounting=yes', '-p', 'RuntimeMaxSec=4200', '--',
        'taskset', '-c', '5-9,15-19', '/tmp/dg424-benchmark-run-python',
        REPO + '/packages/kumo-engine/benchmark/native_io_matrix.py',
        'cell', '--spec', args.prefix + '-spec.json',
    ]
    try:
        subprocess.run(command, env=environment, check=True, timeout=4200)
    finally:
        stop_scope(unit)
        verify_baseline(manifest)
    print(json.dumps(dict(status='PASS', diagnostic_only=True,
                          prefix=args.prefix, regime=args.regime)))


if __name__ == '__main__':
    main()
