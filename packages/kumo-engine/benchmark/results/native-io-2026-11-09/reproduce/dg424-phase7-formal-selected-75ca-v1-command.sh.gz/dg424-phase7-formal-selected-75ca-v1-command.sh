#!/bin/bash
# PLAN ONLY: execute only on explicit root handoff for this window.
set -euo pipefail
exec bash /tmp/dg424-phase6-sequential-plan.sh \
  75ca0e2fd6797827feda61d637b59b75e2d6f678 \
  a5949f96723df2684c6cdbd5884bcc25c72129c8a629bfffa49bc36f9552140f \
  b85a88f9bf09ce88f166c882ea0e1c64e97b743e071e1d924e0552c709e8be0c \
  /tmp/dg424-benchmark-release-75ca0e2f-provenance.json \
  c17db9f37c6a2ffd4d955d2bc57d898da63c7586856eae9ae0299391c2cd68cf \
  /tmp/dg424-phase7-formal-selected.tsv \
  /tmp/dg424-phase7-formal-selected-75ca-v1
