#!/bin/bash
# PLAN ONLY: execute only after root's explicit handoff and paired LP3 proof.
# Pins are supplied arguments; old19a/b9 plans must not be reused.
set -euo pipefail
if [[ $# != 7 ]]; then
  echo "Usage: bash $0 SOURCE_SHA NATIVE_SHA WHEEL_SHA BUILD_JSON BUILD_JSON_SHA JOBS_TSV OUTPUT_ROOT" >&2
  exit 2
fi
bench_source=$1
bench_native_sha=$2
bench_wheel_sha=$3
bench_build=$4
bench_build_sha=$5
bench_jobs=$6
bench_output_root=$7
bench_repo=/home/dmawhirter/work/subtrees/kumo-engine-native-io-benchmarks
bench_python=/tmp/dg424-benchmark-run-python
cd "$bench_repo"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
"$bench_python" - "$bench_source" "$bench_native_sha" "$bench_wheel_sha" "$bench_build" "$bench_build_sha" <<'PYPINS'
import hashlib
import json
import subprocess
import sys
import diskgraph
import diskgraph._c as native
from io_utils import fsutil
source, native_sha, wheel_sha, build_path, build_sha = sys.argv[1:]
def digest(path):
    return hashlib.sha256(fsutil.read_binary(path)).hexdigest()
assert len(source) == 40 and all(c in '0123456789abcdef' for c in source)
assert digest(build_path) == build_sha
build = json.loads(fsutil.read_text(build_path))
assert build['profile'] == 'release' and build['source_git_head'] == source
assert build['native']['sha256'] == native_sha == digest(native.__file__)
assert diskgraph.BUILD_COMMIT == source
assert build['wheel']['sha256'] == wheel_sha == digest(build['wheel']['path'])
assert build['ingest']['sha256'] == digest(build['ingest']['path'])
head = subprocess.run(['git', 'rev-parse', 'HEAD'], check=True,
                      capture_output=True, text=True).stdout.strip()
assert head == source
assert not subprocess.run(['git', 'status', '--porcelain'], check=True,
                          capture_output=True, text=True).stdout
PYPINS
while IFS=$'\t' read -r bench_task bench_regime bench_batches bench_cache bench_reps bench_label bench_extra; do
  if [[ -z "$bench_task" || "${bench_task:0:1}" == "#" ]]; then continue; fi
  [[ -z "$bench_extra" ]]
  case "$bench_task" in binary|regression|temporal_link) ;; *) exit 2 ;; esac
  case "$bench_regime:$bench_cache" in resident:1|resident:16|constrained:1|constrained:2) ;; *) exit 2 ;; esac
  [[ "$bench_batches" =~ ^[1-9][0-9]*$ ]]
  bench_pilot=()
  case "$bench_label" in
    pilot) [[ "$bench_reps" == 1 ]]; bench_pilot=(--pilot) ;;
    formal) [[ "$bench_reps" =~ ^([5-9]|[1-9][0-9]+)$ ]] ;;
    *) exit 2 ;;
  esac
  bench_output=$bench_output_root/${bench_source:0:8}-${bench_native_sha:0:8}-8x256-m1/${bench_task}-${bench_regime}-b${bench_batches}-cache${bench_cache}-n${bench_reps}-${bench_label}
  # Resume only rows from this exact eligibility class; matrix binds all controls.
  "$bench_python" - "$bench_output" "$bench_label" <<'PYRESUME'
import json
import sys
from io_utils import fsutil
root, label = sys.argv[1:]
if fsutil.exists(root):
    for path in fsutil.listdir(root, suffix='.json'):
        if fsutil.isdir(path) or not path.endswith('.json'):
            continue
        row = json.loads(fsutil.read_text(path))
        if 'matrix_spec' not in row or 'phase_seconds' not in row:
            continue
        spec = row['matrix_spec']
        if spec['pilot'] != (label == 'pilot') or spec['min_training_seconds'] != 30.0:
            raise ValueError('Refuse to reuse different eligibility/threshold rows')
PYRESUME
  [[ $(git rev-parse HEAD) == "$bench_source" ]]
  [[ -z $(git status --porcelain) ]]
  "$bench_python" packages/kumo-engine/benchmark/native_io_matrix.py run \
    --prepared-root /tmp/dg424-benchmark-large --output-dir "$bench_output" \
    --runner "$bench_repo/packages/kumo-engine/benchmark/native_io_tasks.py" \
    --python "$bench_python" --build-provenance "$bench_build" \
    --expected-native-sha256 "$bench_native_sha" --resume \
    --tasks "$bench_task" --regimes "$bench_regime" --repetitions "$bench_reps" \
    --steps "$bench_batches" --batch-size 256 --workers 0 --loader-mode standalone \
    --threads 4 --torch-threads 1 --cpus 5-9,15-19 \
    --resident-memory-gib 64 --constrained-memory-gib 4 \
    --direct-cache-gib "$bench_cache" --io-rings 8 --io-qd 256 --io-batch-mult 1 \
    --model-seed 0 --order-seed 20261109 --timeout 3600 \
    --min-training-seconds 30 "${bench_pilot[@]}"
  "$bench_python" - "$bench_output/summary.json" "$bench_label" "$bench_reps" <<'PYRESULT'
import json
import sys
from io_utils import fsutil
path, label, repetitions = sys.argv[1:]
summary = json.loads(fsutil.read_text(path))
assert summary['status'] == 'PASS'
assert summary['repetitions'] == int(repetitions)
assert summary['pilot'] == (label == 'pilot')
assert len(summary['trials']) == 3 * int(repetitions)
assert summary['comparison_status'] == ('EXPLORATORY' if label == 'pilot' else 'REPEATED_PAIRS')
for row in summary['trials']:
    assert row['work']['optimizer_steps'] == row['work']['selected_checkpoint_steps']
    assert row['phase_seconds']['training'] >= 30.0, 'Calibrate longer training before proceeding'
    if row['regime'] == 'constrained':
        assert row['training_evidence']['has_pressure_evidence'], 'No training pressure: recalibrate before next job'
    if row['task'] == 'temporal_link':
        layouts = row['work']['tt_ingest_layouts']
        assert len(layouts) == 4
        assert all(v['requested_num_shards'] == v['actual_num_shards'] == 3
                   for v in layouts)
PYRESULT
done < "$bench_jobs"
