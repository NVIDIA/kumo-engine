"""Prepared model-free probe. Execute only after root GO and other jobs stop."""
import argparse,gc,hashlib,json,os,resource
from io_utils import fsutil
import diskgraph
import diskgraph._c as native

p=argparse.ArgumentParser()
p.add_argument('--output',required=True)
p.add_argument('--go-confirmed',action='store_true')
a=p.parse_args()
if not a.go_confirmed:raise SystemExit('Requires root GO after all other models terminate')
if fsutil.exists(a.output):raise SystemExit('Refusing to overwrite existing evidence')
assert os.environ.get('DG_EDGE_BACKEND')=='direct'
assert os.environ.get('DG_DIRECT_CACHE_GB')=='1'
assert diskgraph.BUILD_COMMIT=='b9aa15d95fbc059ad5b466e638eb986c5cdd653c'
native_sha=hashlib.sha256(fsutil.read_binary(native.__file__)).hexdigest()
assert native_sha=='a5670a9529c03bf1e7893d61223cfe8f1424d613c86fc9e0a5af3eceb4121f25'
manifest=json.loads(fsutil.read_text('/tmp/dg424-benchmark-large/binary/manifest.json'))
root=manifest['snapshot']['index_path']
request=[dict(node_type='users',node_ids=[0,1,2,3,4,16,32,64],feature_names=['value','features'])]
def identity():
 result={}
 for path in manifest['index_files']:
  if path.endswith(('edges.bin','offsets.bin','node_data.ctx')):
   s=os.stat(path)
   result[path]=dict(device=s.st_dev,inode=s.st_ino,size=s.st_size,mtime_ns=s.st_mtime_ns)
 return result
def snapshot():
 io={k:int(v) for line in fsutil.read_text('/proc/self/io').splitlines() for k,v in [line.split(':',1)]}
 usage=resource.getrusage(resource.RUSAGE_SELF)
 return dict(native=diskgraph.page_io_stats().to_dict(),physical_io=io,
             major_faults=usage.ru_majflt,user_seconds=usage.ru_utime,system_seconds=usage.ru_stime)
records=[]
def read(engine,phase):
 before=snapshot()
 events=list(engine.fetch_features(request))
 after=snapshot()
 feature_batches=[event['batch'] for event in events if event['type']=='feature']
 assert sum(batch.num_rows for batch in feature_batches)==8,'Incomplete feature rows'
 assert all({'value','features'} <= set(batch.schema.names) for batch in feature_batches),'Missing requested columns'
 batches=[batch.to_pydict() for batch in feature_batches]
 assert after['native']['configured_backend']=='direct'
 assert after['native']['cache_capacity_pages']==262144
 digest=hashlib.sha256(json.dumps(batches,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
 delta={key:after['native'][key]-before['native'][key] for key in ('submitted','io_ops','bytes','cache_hits','cache_misses','evictions','frames_allocated','frames_reused','frames_recycled','frames_dropped')}
 delta['physical_read_bytes']=after['physical_io']['read_bytes']-before['physical_io']['read_bytes']
 records.append(dict(phase=phase,before=before,after=after,delta=delta,payload_sha256=digest))
 print(json.dumps(dict(phase=phase,delta=delta,payload_sha256=digest)),flush=True)
before_identity=identity()
first=diskgraph.SamplerEngine(root,random_seed=0,num_threads=1)
read(first,'A_cold');read(first,'A_hot')
second=diskgraph.SamplerEngine(root,random_seed=0,num_threads=1)
read(second,'B_reopen_while_A_alive');read(second,'B_hot')
del first,second;gc.collect()
third=diskgraph.SamplerEngine(root,random_seed=0,num_threads=1)
read(third,'C_reopen_after_release');read(third,'C_hot')
after_identity=identity()
assert before_identity==after_identity
assert len({r['payload_sha256'] for r in records})==1
assert all(r['delta']['evictions']==0 for r in records)
for r in records:
 if r['phase'].endswith('_hot'):
  assert r['delta']['cache_hits']>0 and r['delta']['cache_misses']==0
  assert r['delta']['physical_read_bytes']==0
 else:
  assert r['delta']['cache_misses']>0 and r['delta']['physical_read_bytes']>0
result=dict(status='PASS',purpose='Quantify per-open direct-cache reuse without a model',
            pid=os.getpid(),native_path=native.__file__,native_sha256=native_sha,native_build_commit=diskgraph.BUILD_COMMIT,
            requested_backend='direct',requested_cache_gib=1,index_path=root,request=request,
            file_identity_before=before_identity,file_identity_after=after_identity,records=records)
fsutil.write_text(a.output,json.dumps(result,indent=2)+'\n')
