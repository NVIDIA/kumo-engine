"""Diagnostic LP field traces; run only through the explicitly authorized driver."""

import hashlib
import json
import os
import sys
from pathlib import Path
from unittest.mock import patch

import diskgraph
import diskgraph._c as native
import torch

from io_utils import fsutil

REPO = '/home/dmawhirter/work/subtrees/kumo-engine-native-io-benchmarks'
sys.path.insert(0, REPO + '/packages/kumo-engine/benchmark')
import native_io_tasks  # noqa: E402
from kumo_core.train.base_module import BaseLightningModule  # noqa: E402
from native_io_isolation import file_hash, file_tree  # noqa: E402


def tensor_record(tensor: torch.Tensor) -> dict:
    if tensor.device.type != 'cpu':
        raise ValueError('This diagnostic requires CPU tensors')
    value = tensor.detach().contiguous()
    data = value.numpy().tobytes()
    shape = list(value.shape)
    dtype = str(value.dtype)
    header = json.dumps([dtype, shape, len(data)], separators=(',', ':')).encode()
    return dict(sha256=hashlib.sha256(header + data).hexdigest(),
                dtype=dtype, shape=shape, first_values=value.flatten()[:32].tolist())


def positive_record(batch) -> dict:
    store = batch['train_table']
    edges = store.edge_label_index
    size = int(store.batch_size)
    users = batch['users'].n_id[:size].tolist()
    times = (store.time if 'time' in store else store.seed_time).flatten().tolist()
    weights = (store.edge_weight.tolist() if 'edge_weight' in store else
               [1.0] * edges.size(1))
    # Adapter assigns row1 directly from lp_pos_rhs_global: these are global IDs.
    entries = [(int(anchor), int(item), float(weight))
               for (anchor, item), weight in zip(edges.t().tolist(), weights, strict=True)]
    ordered = json.dumps(entries, separators=(',', ':'), allow_nan=False).encode()
    multiset = json.dumps(sorted(entries), separators=(',', ':'), allow_nan=False).encode()
    unique = json.dumps(sorted(set(entries)), separators=(',', ':'), allow_nan=False).encode()
    anchors = [dict(anchor=index, user=users[index], time=times[index], positives=[])
               for index in range(min(size, 32))]
    for anchor, item, weight in entries:
        if anchor < len(anchors):
            anchors[anchor]['positives'].append(dict(global_item=item, weight=weight))
    return dict(destination_ids='global_graph_item_ids',
                weights_present='edge_weight' in store,
                ordered_sha256=hashlib.sha256(ordered).hexdigest(),
                multiset_sha256=hashlib.sha256(multiset).hexdigest(),
                set_sha256=hashlib.sha256(unique).hexdigest(), first_anchors=anchors)


def append(path: str, value: dict) -> None:
    with fsutil.get_binary_handle(path, 'ab') as stream:
        stream.write((json.dumps(value, sort_keys=True, allow_nan=False) + '\n').encode())


def inventory(root: str, private_root: str) -> list[dict]:
    files = []
    for path in sorted(file_tree(root)):
        relative = str(Path(path).relative_to(root))
        record = dict(path=relative, size=fsutil.filesize(path), sha256=file_hash(path))
        if path.endswith('.json') and record['size'] <= 1024**2:
            text = fsutil.read_text(path)
            record['content'] = json.loads(text)
            record['normalized_content'] = json.loads(
                text.replace(private_root, '<PRIVATE_PREPARED>'))
        files.append(record)
    return files


def main() -> None:
    if os.environ.get('DG_LP_TRACE_GO') != '1':
        raise SystemExit('Root GO and no overlapping model jobs are required')
    args = native_io_tasks.arguments()
    if args.build_provenance is None:
        raise ValueError('Diagnostic requires explicit optimized build provenance')
    build = json.loads(fsutil.read_text(str(args.build_provenance)))
    expected_native = build['native']['sha256']
    expected_source = os.environ['DG_LP_TRACE_EXPECTED_SOURCE']
    if (build['profile'] != 'release' or
            build['source_git_head'] != expected_source or
            diskgraph.BUILD_COMMIT != expected_source or
            file_hash(native.__file__) != expected_native):
        raise ValueError('Diagnostic source/native differs from optimized build proof')
    prefix = os.environ['DG_LP_TRACE_PREFIX']
    for suffix in ('-batches.jsonl', '-ingests.jsonl'):
        if fsutil.exists(prefix + suffix):
            raise FileExistsError(prefix + suffix)
    if (args.task != 'temporal_link' or args.backend != 'mmap' or
            args.threads != 1 or args.rayon_threads != 4 or args.workers != 0 or
            args.cleanup_work):
        raise ValueError('Expected retained LP mmap diagnostic, Torch1/Rayon4/workers0')
    trace_batches = int(os.environ.get('DG_LP_TRACE_BATCHES', '8'))
    original_step = BaseLightningModule.training_step
    original_ingest = diskgraph.execute_tt_ingest
    seen = 0
    ingests = []

    def training_step(module, batch, batch_idx):
        nonlocal seen
        if seen >= trace_batches:
            seen += 1
            return original_step(module, batch, batch_idx)
        size = int(batch['train_table'].batch_size)
        fields = {'users.n_id': tensor_record(batch['users'].n_id[:size])}
        if 'input_id' in batch['users']:
            fields['users.input_id'] = tensor_record(batch['users'].input_id[:size])
        if 'items' in batch.node_types and 'n_id' in batch['items']:
            fields['items.n_id'] = tensor_record(batch['items'].n_id)
        store = batch['train_table']
        for name in ('time', 'seed_time', 'y', 'edge_label_index', 'edge_weight'):
            if name in store:
                fields['train_table.' + name] = tensor_record(store[name])
        record = dict(batch=seen, batch_idx=batch_idx, anchor_rows=size,
                      logical_sha256=native_io_tasks.logical_seed_hash(batch),
                      fields=fields, positives=positive_record(batch),
                      rng_before=tensor_record(torch.get_rng_state()))
        if seen < 2:
            with fsutil.get_binary_handle(prefix + f'-batch-{seen}.pt', 'wb') as stream:
                torch.save(batch, stream)
        result = original_step(module, batch, batch_idx)
        record.update(rng_after=tensor_record(torch.get_rng_state()))
        append(prefix + '-batches.jsonl', record)
        seen += 1
        return result

    def ingest(staging_dir, index_path, tt_id, predict_stage_name=None,
               context_threads=None, encode_threads=None, num_shards=None):
        if (context_threads, encode_threads, num_shards) != (1, 1, 3):
            raise ValueError('Diagnostic requires every native ingest1/1 with3 shards')
        source_files = inventory(staging_dir, str(args.prepared_dir))
        result = original_ingest(
            staging_dir=staging_dir, index_path=index_path, tt_id=tt_id,
            predict_stage_name=predict_stage_name,
            context_threads=context_threads, encode_threads=encode_threads,
            num_shards=num_shards)
        extension = str(Path(index_path) / 'train_tables' / tt_id)
        layout = native_io_tasks.tt_shard_layout(Path(extension), 3)
        record = dict(namespace=tt_id, stage_prediction=predict_stage_name,
                      source_staging=staging_dir, extension=extension,
                      context_threads=context_threads, encode_threads=encode_threads,
                      requested_num_shards=num_shards, published_layout=layout,
                      source_files=source_files,
                      files=inventory(extension, str(args.prepared_dir)))
        append(prefix + '-ingests.jsonl', record)
        ingests.append(record)
        return result

    with patch.object(BaseLightningModule, 'training_step', training_step), \
            patch.object(diskgraph, 'execute_tt_ingest', ingest):
        native_io_tasks.main()
    if len(ingests) != 4 or seen != args.steps:
        raise ValueError('Incomplete diagnostic fit or materialization work')
    output = str(args.output)
    result = json.loads(fsutil.read_text(output))
    result['diagnostic'] = dict(
        only=True, purpose='LP cross-regime logical/physical seed and label diagnosis',
        probe_sha256=file_hash(__file__), trace_batches=trace_batches,
        batch_trace=prefix + '-batches.jsonl', ingest_trace=prefix + '-ingests.jsonl',
        retained_private_prepared=str(args.prepared_dir),
        native_sha256=expected_native, native_build_commit=diskgraph.BUILD_COMMIT,
        expected_source=expected_source, requested_num_shards=3)
    fsutil.write_text(output, json.dumps(result, indent=2, allow_nan=False) + '\n')


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        prefix = os.environ.get('DG_LP_TRACE_PREFIX')
        if prefix and os.environ.get('DG_LP_TRACE_GO') == '1':
            path = prefix + '-failure.json'
            if not fsutil.exists(path):
                fsutil.write_text(path, json.dumps(dict(
                    status='FAILED_DIAGNOSTIC', error_type=type(error).__name__,
                    error=str(error), probe_sha256=file_hash(__file__)), indent=2) + '\n')
        raise
