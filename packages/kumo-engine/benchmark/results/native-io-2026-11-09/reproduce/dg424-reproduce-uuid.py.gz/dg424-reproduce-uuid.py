"""Run the preserved UUID proof against the committed pre-control harness."""
import os
import runpy
import subprocess
import sys
import types
from pathlib import Path

repo = Path('/home/dmawhirter/work/subtrees/kumo-engine-native-io-benchmarks')
revision = 'b1ae754f713436d145ac2784aaadb89b892569c6'
source_file = 'packages/kumo-engine/benchmark/native_io_tasks.py'
source = subprocess.check_output(
    ['git', 'show', f'{revision}:{source_file}'], cwd=repo, text=True)
sys.path.insert(0, str(repo / 'packages/kumo-engine/benchmark'))
module = types.ModuleType('native_io_tasks')
module.__file__ = str(repo / source_file)
sys.modules['native_io_tasks'] = module
exec(compile(source, module.__file__, 'exec'), module.__dict__)
runpy.run_path('/tmp/dg424-parity-probe.py', run_name='__main__')
